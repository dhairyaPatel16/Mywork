﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTDhairyaPatel
{
    public enum vCategory
    {
        Hatchback, Sedan, SUV, Cruiser, Sports, Dirt
    }

    public enum vType
    {
        Standard, Exotic, Bike, Trike
    } 
    public abstract class Vehicle
    {
    

        protected Vehicle(int iD, string carName, double rentalPrice, vCategory category, vType type, bool isReserved)
        {
            ID = iD;
            CarName = carName;
            RentalPrice = rentalPrice;
            Category = (vCategory)category;
            Type = (vType)type;
            IsReserved = isReserved;
        }

        public int ID { get; set; }
        public string CarName { get; set; }
        public double RentalPrice { get; set; }
        public vCategory Category { get; set; }
        public vType Type { get; set; }
        public bool IsReserved { get; set; }

        
    }

}
