﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTDhairyaPatel
{
    public class Car : Vehicle
    {
        public Car(int iD, string carName, double rentalPrice, vCategory category, vType type, bool isReserved) : base(iD, carName, rentalPrice, category , type, isReserved)
        {
        }

        public bool isCar {  get; set; }
    }
}
