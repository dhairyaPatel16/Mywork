﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MTDhairyaPatel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Vehicle> actualvehicles;
        private List<Vehicle> vehicles;
        public MainWindow()
        {
            InitializeComponent();

            actualvehicles = new List<Vehicle>()
            {
                new Car(1, "Honda Civic", 69.9, vCategory.Sedan, vType.Standard, true),
                new Car(2, "Toyota Corolla", 69.9, vCategory.Sedan, vType.Standard, false),
                new Car(3, "Ford Explorer", 99.9, vCategory.SUV, vType.Standard, true),
                new Car(4, "Nissan Versa", 49.9, vCategory.Hatchback, vType.Standard, false),
                new Motorcycle(5, "Suzuki Boulevard M109R", 49.9, vCategory.Cruiser, vType.Bike, true),
                new Motorcycle(6, "Harley-Davidson Street Glide", 79.9, vCategory.Cruiser, vType.Bike, false),
                new Motorcycle(7, "Honda CRF125", 39.9, vCategory.Dirt, vType.Bike, true)
            };

            vehicles = new List<Vehicle>(actualvehicles);
            RefreshListBox();
        }

        private void RefreshListBox()
        {
            var carName = from car in actualvehicles
                          select car.CarName;

            lstVehicle.ItemsSource = carName;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            cmbCategory.ItemsSource = Enum.GetValues(typeof(vCategory));
            cmbType.ItemsSource = Enum.GetValues(typeof (vType));
            RefreshListBox();
        }

        private void lstVehicle_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if(lstVehicle.SelectedItem != null)
            {
                Vehicle vehicle = actualvehicles[lstVehicle.SelectedIndex];
                
                if(vehicle is Car) { rdo1.IsChecked = true; }else if(vehicle is Motorcycle) { rdo2.IsChecked = true; }
                txtId.Text = vehicle.ID.ToString();
                txtName.Text = vehicle.CarName;
                txtRentalPrice.Text = vehicle.RentalPrice.ToString();
               cmbCategory.SelectedItem = vehicle.Category;
                cmbType.SelectedItem = vehicle.Type;
                chkReserved.IsChecked = vehicle.IsReserved;
                btnDelete.IsEnabled = true;
                btnEdit.IsEnabled = true;
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lstVehicle.ItemsSource = null;
            MessageBox.Show("Your ListBox is Clear");
            return;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if(rdo1.IsChecked == false && rdo2.IsChecked == false) 
            {
                MessageBox.Show("Please Select the Valid option for car or Motorcycle"); 
                return;
            }

            if(txtName.Text == "" || txtRentalPrice.Text == "")
            {
                MessageBox.Show("Please Enter Valid CarName or RentalPrice");
                return;
            }

            int id = 1; 
            if(actualvehicles.Count > 0)
                id = actualvehicles.Last().ID + 1;

            string carName = txtName.Text;
            double rentalPrice = double.Parse(txtRentalPrice.Text);
            vCategory category = (vCategory)cmbCategory.SelectedItem;
            vType type = (vType)cmbType.SelectedItem;
            bool isReserved = chkReserved.IsChecked ?? false;

            if(rdo1.IsChecked == true)
            {
                Car car = new Car(id, carName, rentalPrice, category, type, isReserved);
                actualvehicles.Add(car);
                MessageBox.Show("New Car is Added");
            }

            else if(rdo2.IsChecked == true)
            {
                Motorcycle motorcycle = new Motorcycle(id, carName, rentalPrice, category, type, isReserved);
                actualvehicles.Add(motorcycle);
                MessageBox.Show("New Motorcycle is Added");
            }

            txtId.Text = id.ToString();
            RefreshListBox();
        }

        private void btnClear1_Click(object sender, RoutedEventArgs e)
        {
            txtId.Text = txtName.Text = txtRentalPrice.Text = cmbCategory.Text = cmbType.Text = "";
            chkReserved.IsChecked = false;
            rdo1.IsChecked = false;
            rdo2.IsChecked = false;
            btnDelete.IsEnabled = false;
            btnEdit.IsEnabled = false;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if(lstVehicle.SelectedItems != null)
            {
                Vehicle vehicle = actualvehicles[lstVehicle.SelectedIndex];
                actualvehicles.Remove(vehicle);

                RefreshListBox();
                txtId.Text = txtName.Text = txtRentalPrice.Text = cmbCategory.Text = cmbType.Text = "";
                chkReserved.IsChecked = false;
                rdo1.IsChecked = false;
                rdo2.IsChecked = false;
                btnDelete.IsEnabled = false;
                btnEdit.IsEnabled = false;
                MessageBox.Show("Vehicle is Removed Successfully");

            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            Vehicle vehicle = actualvehicles[lstVehicle.SelectedIndex];

            if (rdo1.IsChecked == false && rdo2.IsChecked == false)
            {
                MessageBox.Show("Please Select the Valid option for car or Motorcycle");
                return;
            }

            if (txtName.Text == "" || txtRentalPrice.Text == "")
            {
                MessageBox.Show("Please Enter Valid CarName or RentalPrice");
                return;
            }

            if (vehicle is Car) { rdo1.IsChecked = true; } else if (vehicle is Motorcycle) { rdo2.IsChecked = true; }
            vehicle.CarName = txtName.Text;
            vehicle.RentalPrice = double.Parse(txtRentalPrice.Text);
            vehicle.Category = (vCategory)cmbCategory.SelectedItem;
            vehicle.Type = (vType)cmbType.SelectedItem;
            vehicle.IsReserved = chkReserved.IsChecked ?? false;

            RefreshListBox();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
           actualvehicles.Clear();
            actualvehicles.AddRange(vehicles);

            RefreshListBox();

            MessageBox.Show("Your ListBox is Reset to Default");
        }
    }
}
