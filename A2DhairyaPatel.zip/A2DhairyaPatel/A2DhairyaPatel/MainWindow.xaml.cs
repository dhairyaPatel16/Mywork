﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;


namespace A2DhairyaPatel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadCmbBox();
            LoadGrid();
        }

       private void LoadCmbBox()
        {
            SqlConnection conn = new SqlConnection(Data.ConnectionString);
            DataTable dtAttor = new DataTable();
            string query = "Select LastName from Attorneys";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dtAttor.Load(reader);
            cmbAttor.ItemsSource = dtAttor.DefaultView;
            conn.Close();
            cmbAttor.DisplayMemberPath = "LastName";
        }

        private void LoadGrid()
        {
            SqlConnection conn = new SqlConnection( Data.ConnectionString );
            DataTable dtGrid = new DataTable();
            string query = "SELECT Billing.BillingID, FORMAT(Billing.Date, 'dd-MMM-yyyy') AS Date,Billing.Hours AS Hours, Clients.FirstName AS ClientFirstName, Clients.LastName AS ClientLastName, Attorneys.FirstName AS AttorneyFirstName, Attorneys.LastName AS AttorneyLastName, Categories.Category, Rates.Rate " +
                   "FROM Billing " +
                   "INNER JOIN Clients ON Billing.ClientID = Clients.ClientID " +
                   "INNER JOIN Attorneys ON Billing.AttorneyID = Attorneys.AttorneyID " +
                   "INNER JOIN Categories ON Billing.CategoryID = Categories.CategoryID " +
                   "INNER JOIN Rates ON Billing.RateID = Rates.RateID";
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            dtGrid.Load(reader);
            dtDgrid.ItemsSource = dtGrid.DefaultView;
            conn.Close();
        }

        private void cmbAttor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(cmbAttor.SelectedItem != null)
            {
                string selectedLastName = ((DataRowView)cmbAttor.SelectedItem)["LastName"].ToString();
                using (SqlConnection conn = new SqlConnection(Data.ConnectionString))
                {
                    DataTable dtGrid = new DataTable();
                    
                    string query = $"SELECT Billing.BillingID, FORMAT(Billing.Date, 'dd-MMM-yyyy') AS Date,Billing.Hours AS Hours, Clients.FirstName AS ClientFirstName, Clients.LastName AS ClientLastName, Attorneys.FirstName AS AttorneyFirstName, Attorneys.LastName AS AttorneyLastName, Categories.Category, Rates.Rate FROM Billing INNER JOIN Clients ON Billing.ClientID = Clients.ClientID INNER JOIN Attorneys ON Billing.AttorneyID = Attorneys.AttorneyID INNER JOIN Categories ON Billing.CategoryID = Categories.CategoryID INNER JOIN Rates ON Billing.RateID = Rates.RateID WHERE Attorneys.LastName = @AttorneyLastName";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AttorneyLastName", selectedLastName);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    dtGrid.Load(reader);
                    dtDgrid.ItemsSource = dtGrid.DefaultView;
                }
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query = $"SELECT Billing.BillingID, FORMAT(Billing.Date, 'dd-MMM-yyyy') AS Date,Billing.Hours AS Hours, Clients.FirstName AS ClientFirstName, Clients.LastName AS ClientLastName, Attorneys.FirstName AS AttorneyFirstName, Attorneys.LastName AS AttorneyLastName, Categories.Category, Rates.Rate FROM Billing INNER JOIN Clients ON Billing.ClientID = Clients.ClientID INNER JOIN Attorneys ON Billing.AttorneyID = Attorneys.AttorneyID INNER JOIN Categories ON Billing.CategoryID = Categories.CategoryID INNER JOIN Rates ON Billing.RateID = Rates.RateID WHERE (Clients.FirstName LIKE '%' + @ClientName + '%') OR (Clients.LastName LIKE '%' + @ClientName + '%')";

            using (SqlConnection conn = new SqlConnection(Data.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ClientName", txtClients.Text);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                DataTable dtGrid = new DataTable();
                dtGrid.Load(reader);
                dtDgrid.ItemsSource = dtGrid.DefaultView;
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DateTime StartDate = pickStartDate.SelectedDate ?? DateTime.MinValue;
            DateTime EndDate = pickEndDate.SelectedDate ?? DateTime.MaxValue;

            string query = $"SELECT Billing.BillingID, FORMAT(Billing.Date, 'dd-MMM-yyyy') AS Date,Billing.Hours AS Hours, Clients.FirstName AS ClientFirstName, Clients.LastName AS ClientLastName, Attorneys.FirstName AS AttorneyFirstName, Attorneys.LastName AS AttorneyLastName, Categories.Category, Rates.Rate FROM Billing INNER JOIN Clients ON Billing.ClientID = Clients.ClientID INNER JOIN Attorneys ON Billing.AttorneyID = Attorneys.AttorneyID INNER JOIN Categories ON Billing.CategoryID = Categories.CategoryID INNER JOIN Rates ON Billing.RateID = Rates.RateID WHERE (Billing.Date >= @startDate) AND (Billing.Date <= @endDate)";

            using (SqlConnection conn = new SqlConnection(Data.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@startDate", StartDate);
                cmd.Parameters.AddWithValue("@endDate", EndDate);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                DataTable dtGrid = new DataTable();
                dtGrid.Load(reader);
                dtDgrid.ItemsSource = dtGrid.DefaultView;
            }
        }

        private void btnBills_Click(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void btnFields_Click(object sender, RoutedEventArgs e)
        {
            cmbAttor.SelectedItem = null;
            dtDgrid.ItemsSource = null;
            pickStartDate.SelectedDate = null;
            pickEndDate.SelectedDate = null;
            txtClients.Text = null;
            txtBillId.Text = null;
            txtAttorneys.Text = null;
            txtCategory.Text = null;
            txtClientName.Text = null;
            txtFee.Text = null;
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            int BillID = int.Parse(txtBillId.Text);
            string query = $"SELECT Billing.BillingID, Clients.FirstName AS ClientFirstName, Clients.LastName AS ClientLastName, Attorneys.FirstName AS AttorneyFirstName, Attorneys.LastName AS AttorneyLastName, Billing.Hours, Rates.Rate, Categories.Category FROM Billing INNER JOIN Clients ON Billing.ClientID = Clients.ClientID INNER JOIN Attorneys ON Billing.AttorneyID = Attorneys.AttorneyID INNER JOIN Rates ON Billing.RateID = Rates.RateID INNER JOIN Categories ON Billing.CategoryID = Categories.CategoryID WHERE Billing.BillingID = @billID";


            using (SqlConnection conn = new SqlConnection(Data.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@billID", BillID);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string ClientName = $"{reader["ClientFirstName"]} {reader["ClientLastName"]}";
                    string AttorneyName = $"{reader["AttorneyFirstName"]} {reader["AttorneyLastName"]}";
                    string CategoryName = $"{reader["Category"]}";

                    txtClientName.Text = $"{ClientName}";
                    txtAttorneys.Text = $"{AttorneyName}";
                    txtCategory.Text = $"{CategoryName}";

                    int h = Convert.ToInt32(reader["Hours"]);
                    int r = Convert.ToInt32(reader["Rate"]);

                    int fees = h * r;
                    txtFee.Text = fees.ToString("C");

                }

                else
                {
                    txtBillId = null;
                    txtAttorneys = null;    
                    txtClientName = null;
                    txtFee.Text = null;
                    MessageBox.Show("No Recoard Found");
                }
            }
        }
    }
}