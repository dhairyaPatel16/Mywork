﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FinalDhairyaPatel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using(var db = new BooksDBEntities())
            {
                cmbAuthors.ItemsSource = db.Authors.ToList();
                cmbAuthors.DisplayMemberPath = "LastName";
                cmbAuthors.SelectedValuePath = "AuthorID";

                cmbPublishers.ItemsSource = db.Publishers.ToList();
                cmbPublishers.DisplayMemberPath = "Name";
                cmbPublishers.SelectedValuePath = "PublisherID";
            }
        }

        private void btnAuthor_Click(object sender, RoutedEventArgs e)
        {
            using(var db = new BooksDBEntities())
            {
                var books = db.Authors.Select(b => new {b.AuthorID, b.FirstName, b.LastName, b.City, b.State}).ToList();
                grdBooks.ItemsSource = books;
                grdBooks.Columns[0].Header = "Author ID";
                grdBooks.Columns[1].Header = "First Name";
                grdBooks.Columns[2].Header = "Last Name";

            }
        }

        private void btnPublishers_Click(object sender, RoutedEventArgs e)
        {
            using(var db = new BooksDBEntities())
            {
                var books = db.Publishers.Select(p => new {p.PublisherID, p.Name, p.City, p.State}).ToList();
                grdBooks.ItemsSource = books;
                grdBooks.Columns[0].Header = "Publisher ID";
            }
        }

        private void btnTitles_Click(object sender, RoutedEventArgs e)
        {
            using( var db = new BooksDBEntities())
            {
                var books = db.Titles.Select(t => new {t.TitleID, t.Title1, t.Publisher.Name, t.Price}).ToList();
                grdBooks.ItemsSource = books;
                grdBooks.Columns[0].Header= "Title ID";
                grdBooks.Columns[1].Header = "Title";
                grdBooks.Columns[2].Header = "Publisher";
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string title = txtTitles.Text.ToLower();
            using(var db = new BooksDBEntities())
            {
                var books = db.Titles.Where(t => t.Title1.ToLower().Contains(title)).Select(t => new { t.TitleID, t.Title1, t.Publisher.Name, t.Price }).ToList();
                if(books.Count > 0)
                {
                    grdBooks.ItemsSource= books;
                    grdBooks.Columns[0].Header = "Title ID";
                    grdBooks.Columns[1].Header = "Title";
                    grdBooks.Columns[2].Header = "Publisher";
                }
                else
                {
                    MessageBox.Show("No Record Found");
                }
            }
        }

        private void cmbAuthors_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Author authorSelected = cmbAuthors.SelectedItem as Author;
            if (authorSelected != null)
            {
                using (var db = new BooksDBEntities())
                {
                    var books = db.Titles.Where(t => t.Authors.Any(a => a.AuthorID == authorSelected.AuthorID)).Select(t => new { t.TitleID, t.Title1, t.Price }).ToList();
                    grdBooks.ItemsSource = books;
                    grdBooks.Columns[0].Header = "Title ID";
                    grdBooks.Columns[1].Header = "Title";
                }
            }
        }

        private void cmbPublishers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbPublishers.SelectedItem != null)
            {
                Publisher publisherSelected = cmbPublishers.SelectedItem as Publisher;
                
                using(var db = new BooksDBEntities())
                {
                    var books = db.Titles.Where(t => t.Publisher.PublisherID == publisherSelected.PublisherID).Select(t => new { t.TitleID, t.Title1, t.Price }).ToList();
                    grdBooks.ItemsSource = books;
                    grdBooks.Columns[0].Header = "Title ID";
                    grdBooks.Columns[1].Header = "Title";
                }
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtTitles.Text = "";
            grdBooks.ItemsSource = null;
            cmbAuthors.SelectedItem = null;
            cmbPublishers.SelectedItem = null;
        }

    }
}
