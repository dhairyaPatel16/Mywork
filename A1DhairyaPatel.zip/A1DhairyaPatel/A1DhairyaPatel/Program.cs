﻿using System;
using ConsoleTables;

namespace A1DhairyaPatel
{
    internal class Program
    {


        static void Main(string[] args)
        {

            List<Vehicle> vehicles = new List<Vehicle>();
            {
                vehicles.Add(new Car(1, "Honda Civic", 69.9, "Sedan", "Standard"));
                vehicles.Add(new Car(2, "Toyota Corolla", 69.9, "Sedan", "Standard"));
                vehicles.Add(new Car(3, "Ford Explorer", 99.9, "SUV", "Standard"));
                vehicles.Add(new Car(4, "Nissan Versa", 49.9, "Hatchback", "Standard"));
                vehicles.Add(new Car(5, "Hyundai Tucson", 89.9, "SUV", "Standard"));
                vehicles.Add(new Car(6, "Lamborghini Aventador", 189.9, "Sports", "Exotic"));
                vehicles.Add(new Car(7, "Ferrari 488 GTB", 179.9, "Sports", "Exotic"));
                vehicles.Add(new Car(8, "McLaren P1", 199.9, "Sports", "Exotic"));
                vehicles.Add(new Motorcycle(9, "Suzuki Boulevard M109R", 49.9, "Cruiser", "Bike"));
                vehicles.Add(new Motorcycle(10, "Harley-Davidson Street Glide", 79.9, "Cruiser", "Bike"));
                vehicles.Add(new Motorcycle(11, "Honda CRF125", 39.9, "Dirt", "Bike"));
                vehicles.Add(new Motorcycle(12, "Ducati Monster", 69.9, "Sports", "Bike"));
                vehicles.Add(new Motorcycle(13, "Can-Am Spyder", 59.9, "Cruiser", "Trike"));
                vehicles.Add(new Motorcycle(14, "Polaris Slingshot", 69.9, "Cruiser", "Trike"));
            };

            Console.WriteLine("\n\tAsignment-1 by DHAIRYA PATEL");
            Console.WriteLine("\n\n\n+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n\n");

            bool exitApp = false;
            while (!exitApp)
            {
                Console.WriteLine("\t1 - View all vehicles");
                Console.WriteLine("\t2 - View available vehicles");
                Console.WriteLine("\t3 - View reserved vehicles");
                Console.WriteLine("\t4 - Reserve a vehicle");
                Console.WriteLine("\t5 - Cancel reservation");
                Console.WriteLine("\t6 - Exit");

                Console.Write("\n\nEnter your choice:");
                int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
                {


                    switch (choice)
                    {
                        case 1:
                            Console.Clear();
                            Display(vehicles);
                            break;

                        case 2:

                            ViewAvailable(vehicles);
                            break;

                        case 3:

                            ViewReserved(vehicles);
                            break;

                        case 4:
                            Console.Clear();
                            VehicleReserve(vehicles);
                            break;

                        case 5:
                            CancelReservation(vehicles);
                            break;

                        case 6:
                            exitApp = true;
                            Console.WriteLine("GOOD BYE..");
                            Console.WriteLine("Press any key to continue....");
                            Console.ReadKey();
                            break;

                        default:
                            Console.WriteLine("Invalid selection. Please close it and try again..");
                            break;

                    }

                    
                }
            
        
                else
                {
                    Console.WriteLine("Invalid user input. Try Again..");
                }
                
            }
            
        }


             static void Display(List<Vehicle> vehicles)
        {
                Console.Clear();
            ConsoleTable table = new ConsoleTable("ID", "Name", "Rental Price","Category", "Type", "Available");
            foreach (var i in vehicles)
            {
                string is_Reserve = i.IsReserved ? "No" : "Yes";
                table.AddRow(i.ID, i.CarName, i.RentalPrice.ToString("C"), i.Category, i.Type, is_Reserve);
            }
            table.Write(Format.MarkDown);
            Console.WriteLine("\n\n");
            
    }

        static void ViewAvailable(List<Vehicle> vehicles)
        {
            Console.Clear();
            Console.WriteLine("\nAvailable Vehicle\n\n");
            var allAvailable = from c in vehicles 
                               where c.IsReserved == false 
                               select c;

            ConsoleTable table = new ConsoleTable("ID", "Name", "Rental Price", "Category", "Type");

            foreach (var i in allAvailable)
                table.AddRow(i.ID, i.CarName, i.RentalPrice.ToString("C"), i.Category, i.Type);
            table.Write(Format.MarkDown);
            Console.WriteLine("\n\n");
            
        }

        static void ViewReserved(List<Vehicle> vehicles)
        {
            Console.Clear();
            var Reserved = from c in vehicles
                           where c.IsReserved == true 
                           select c;
            if (Reserved.Any())
            {
                Console.WriteLine("\nReserved Vehicles:\n\n");
                ConsoleTable table = new ConsoleTable("ID", "Name", "Rental Price", "Category", "Type", "Available");

                foreach (var i in Reserved)
                {
                    string is_Reserve = i.IsReserved ? "No" : "Yes";
                    table.AddRow(i.ID, i.CarName, i.RentalPrice.ToString("C"), i.Category, i.Type, is_Reserve);
                }
                table.Write(Format.MarkDown);
                Console.WriteLine("\n\n");
                
            }

            else {
                Console.WriteLine("No Record found");
            }
        }

        static void VehicleReserve(List<Vehicle> vehicles)
        {
            
            ViewAvailable(vehicles);
            Console.Write("\n\nEnter the ID to reserve: ");
            int user = Convert.ToInt32(Console.ReadLine());
            Console.Clear();

            var reserveVehicle = from c in vehicles
                                 where c.ID == user
                                 where c.IsReserved = true
                                 select c;
            Console.WriteLine("\nVehicle Reservation Successful\n");
            ConsoleTable table = new ConsoleTable("ID", "Name", "Rental Price", "Category", "Type", "Available");
            foreach (var i in reserveVehicle)
            {
                string is_Reserve = i.IsReserved ? "No" : "Yes";
                table.AddRow(i.ID, i.CarName, i.RentalPrice.ToString("C"), i.Category, i.Type, is_Reserve);
            }
                table.Write(Format.MarkDown);
                Console.WriteLine("\n\n");
           
            
        }

        static void CancelReservation(List<Vehicle> vehicles)
        {
            ViewReserved(vehicles);
            Console.Write("\n\nEnter the ID to reserve: ");
            int user = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("\nVehicle Reservation Cancelled Successfully\n\n");
            var cancelReservation = from c in vehicles
                                    where c.ID == user
                                    where c.IsReserved = false
                                    select c;
           
            ConsoleTable table = new ConsoleTable("ID", "Name", "Rental Price", "Category", "Type", "Available");
            foreach (var i in cancelReservation)
            {
                string is_Reserve = i.IsReserved ? "No" : "Yes";
                table.AddRow(i.ID, i.CarName, i.RentalPrice.ToString("C"), i.Category, i.Type, is_Reserve);
            }
            table.Write(Format.MarkDown);
            Console.WriteLine("\n\n");
        }


    }
       
}
    
