﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A1DhairyaPatel
{
    public class Motorcycle : Vehicle
    {
        public Motorcycle(int id, string name, double rentalprice, string category, string type) 
        {
            ID = id;
            CarName = name;
            RentalPrice = rentalprice;
            Category = category;
            Type = type;
            IsReserved = false;
        }
    }
}
